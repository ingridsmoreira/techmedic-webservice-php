<?php
define("DB_HOST", "blodhkhmkswx16pnq3qp-mysql.services.clever-cloud.com");
define("DB_USERNAME", "uothcnongbiyeivw");
define("DB_PASSWORD", "wdx433tIpq7jzl3LtlB1");
define("DB_DATABASE_NAME", "blodhkhmkswx16pnq3qp");
?>